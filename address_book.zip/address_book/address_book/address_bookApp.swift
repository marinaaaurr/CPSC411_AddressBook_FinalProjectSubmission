//
//  address_bookApp.swift
//  address_book
//
//  Created by Audrey Urrutia on 12/1/21.
//

import SwiftUI

@main
struct address_bookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
