//
//  ContactDetailsTableViewController.swift
//  address_book
//
//  Created by Marina Urrutia on 12/9/21.
//

import UIKit

class ContactDetailsTableViewController: UITableViewController {

    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var lblEmailAddress: UILabel!
    
    var contact : ContactPerson!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblFirstName.text = contact.firstName
        lblLastName.text = contact.lastName
        lblEmailAddress.text = contact.emailAddress
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
