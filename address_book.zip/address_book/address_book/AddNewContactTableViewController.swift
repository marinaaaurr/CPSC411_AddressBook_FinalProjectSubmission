//
//  AddNewContactTableViewController.swift
//  address_book
//
//  Created by Audrey Urrutia on 12/9/21.
//

import UIKit

class AddNewContactTableViewController: UITableViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtEmailAddress: UITextField!
    var contact: ContactPerson!
    
    override func viewDidLoad() {
        super.viewDidLoad()

   }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

   
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "SaveSegue"){
            contact = ContactPerson( withFirstName: txtFirstName.text!, lastName: txtLastName.text!, emailAddress: txtLastName.text!)
        }
    }
    

}
